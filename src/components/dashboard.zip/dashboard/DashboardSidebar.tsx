import React, { useState } from "react";
import { Home, User, Box, Share2, Gift, Heart, MessageCircle, Settings, LogOut } from "react-feather";

interface DashboardSidebarProps {
  activePanel: string;
  setActivePanel: (key: string) => void;
}

const sidebarSections = [
  { label: "Dashboard", key: "dashboard", icon: <Home size={20} /> },
  { label: "My Profile", key: "profile", icon: <User size={20} /> },
  { label: "My Orders", key: "view-orders", icon: <Box size={20} /> },
  { label: "Referrals & Network", key: "referrals", icon: <Share2 size={20} /> },
  { label: "Rewards & Offers", key: "rewards", icon: <Gift size={20} /> },
  { label: "Wishlist", key: "wishlist", icon: <Heart size={20} /> },
  { label: "Support & Tickets", key: "support", icon: <MessageCircle size={20} /> },
  { label: "Settings", key: "settings", icon: <Settings size={20} /> },
  { label: "Logout", key: "logout", icon: <LogOut size={20} /> },
];

const DashboardSidebar: React.FC<DashboardSidebarProps> = ({ activePanel, setActivePanel }) => {
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  const handleSidebarClick = (key: string) => {
    if (key === "logout") {
      setShowLogoutModal(true);
    } else {
      setActivePanel(key);
    }
  };

  const handleLogout = () => {
    setShowLogoutModal(false);
    // Add real logout logic here
    alert("Logged out (demo)");
  };

  return (
    <>
      <nav className="dashboard-sidebar">
        <div className="sidebar-logo">GiftsHero</div>
        {sidebarSections.map((section) => (
          <button
            key={section.key}
            className={`sidebar-btn${activePanel === section.key ? " active" : ""}`}
            onClick={() => handleSidebarClick(section.key)}
          >
            <span className="sidebar-icon">{section.icon}</span>
            {section.label}
          </button>
        ))}
      </nav>
      {showLogoutModal && (
        <div className="logout-modal-overlay fade-in">
          <div className="logout-modal-card">
            <div className="logout-modal-icon"><LogOut size={36} /></div>
            <div className="logout-modal-title">Are you sure you want to logout?</div>
            <div className="logout-modal-actions">
              <button className="logout-modal-btn" onClick={() => setShowLogoutModal(false)}>Cancel</button>
              <button className="logout-modal-btn logout" onClick={handleLogout}>Logout</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default DashboardSidebar; 