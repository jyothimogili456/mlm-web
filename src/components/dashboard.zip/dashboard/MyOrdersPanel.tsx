import React, { useState } from "react";
import { CheckCircle, Truck, Clock, FileText } from "react-feather";
import { jsPDF } from "jspdf";
import "./MyOrdersPanel.css";

const orders = [
  { id: "ORD1234", product: "Wireless Earbuds", date: "2024-05-01", status: "Delivered", amount: 1999 },
  { id: "ORD1235", product: "Smart Watch", date: "2024-04-28", status: "Shipped", amount: 2999 },
  { id: "ORD1236", product: "Gift Card", date: "2024-04-20", status: "Processing", amount: 500 },
  { id: "ORD1237", product: "Bluetooth Speaker", date: "2024-04-18", status: "Delivered", amount: 1499 },
  { id: "ORD1238", product: "Fitness Band", date: "2024-04-15", status: "Shipped", amount: 999 },
];
const statusOptions = ["All", "Delivered", "Shipped", "Processing"];
const dateOptions = ["All", "Last 7 days", "Last 30 days", "2024-05", "2024-04"];
const ORDERS_PER_PAGE = 3;

function getStatusIcon(status: string) {
  if (status === "Delivered") return <CheckCircle size={18} className="order-status-icon delivered" />;
  if (status === "Shipped") return <Truck size={18} className="order-status-icon shipped" />;
  return <Clock size={18} className="order-status-icon processing" />;
}

export default function MyOrdersPanel() {
  const [statusFilter, setStatusFilter] = useState("All");
  const [dateFilter, setDateFilter] = useState("All");
  const [page, setPage] = useState(1);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);

  const filteredOrders = orders.filter(order => {
    const statusMatch = statusFilter === "All" || order.status === statusFilter;
    const dateMatch =
      dateFilter === "All" ||
      (dateFilter === "Last 7 days" && new Date(order.date) >= new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)) ||
      (dateFilter === "Last 30 days" && new Date(order.date) >= new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)) ||
      (dateFilter.length === 7 && order.date.startsWith(dateFilter));
    return statusMatch && dateMatch;
  });

  const totalPages = Math.ceil(filteredOrders.length / ORDERS_PER_PAGE);
  const paginatedOrders = filteredOrders.slice((page - 1) * ORDERS_PER_PAGE, page * ORDERS_PER_PAGE);

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages) setPage(newPage);
  };

  // Reset to page 1 when filters change
  React.useEffect(() => { setPage(1); }, [statusFilter, dateFilter]);

  const handleDownload = (orderId: string) => {
    setDownloadingId(orderId);
    const order = orders.find(o => o.id === orderId);
    setTimeout(() => {
      const doc = new jsPDF();
      doc.setFontSize(18);
      doc.text("GiftsHero Invoice", 20, 20);
      doc.setFontSize(12);
      doc.text(`Order ID: ${order?.id || "-"}`, 20, 40);
      doc.text(`Product: ${order?.product || "-"}`, 20, 50);
      doc.text(`Date: ${order?.date || "-"}`, 20, 60);
      doc.text(`Amount: ₹${order?.amount || "-"}`, 20, 70);
      doc.text(`Status: ${order?.status || "-"}`, 20, 80);
      doc.text("\nThank you for your purchase!\n\n(This is a demo PDF.)", 20, 100);
      doc.save(`invoice-${orderId}.pdf`);
      setDownloadingId(null);
    }, 800);
  };

  return (
    <div className="orders-dashboard-panel">
      <div className="orders-filters-row">
        <div className="orders-filter-group">
          <label>Status:</label>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="orders-filter-select">
            {statusOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </div>
        <div className="orders-filter-group">
          <label>Date:</label>
          <select value={dateFilter} onChange={e => setDateFilter(e.target.value)} className="orders-filter-select">
            {dateOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
          </select>
        </div>
      </div>
      <div className="orders-table-wrapper">
        <table className="orders-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Product</th>
              <th>Date</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Invoice</th>
            </tr>
          </thead>
          <tbody>
            {paginatedOrders.map((order, i) => (
              <tr key={order.id} className={i % 2 === 0 ? "orders-row-even" : "orders-row-odd"}>
                <td>{order.id}</td>
                <td>{order.product}</td>
                <td>{order.date}</td>
                <td>₹{order.amount}</td>
                <td className="orders-status-cell">
                  {getStatusIcon(order.status)}
                  <span className={`orders-status-text orders-status-${order.status.toLowerCase()}`}>{order.status}</span>
                </td>
                <td>
                  <button className="orders-invoice-btn" onClick={() => handleDownload(order.id)} disabled={downloadingId === order.id}>
                    <FileText size={16} style={{ marginRight: 4 }} />
                    {downloadingId === order.id ? "Downloading..." : "Download"}
                  </button>
                </td>
              </tr>
            ))}
            {paginatedOrders.length === 0 && (
              <tr><td colSpan={6} className="orders-empty">No orders found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <div className="orders-pagination-row">
          <button className="orders-pagination-btn" onClick={() => handlePageChange(page - 1)} disabled={page === 1}>Previous</button>
          {[...Array(totalPages)].map((_, idx) => (
            <button
              key={idx + 1}
              className={`orders-pagination-btn${page === idx + 1 ? " active" : ""}`}
              onClick={() => handlePageChange(idx + 1)}
            >
              {idx + 1}
            </button>
          ))}
          <button className="orders-pagination-btn" onClick={() => handlePageChange(page + 1)} disabled={page === totalPages}>Next</button>
        </div>
      )}
    </div>
  );
} 