import React, { useState } from "react";
import { Users, Link as LinkIcon, Copy, Share2, Gift, Calendar, DollarSign } from "react-feather";
import QRCode from "react-qr-code";
import "./ReferralsPanel.css";

const referralLink = "https://giftshero.com/ref/GH1234";
const referrals = [
  { name: "Amit Kumar", joinDate: "2024-04-10", earnings: 200 },
  { name: "Priya Singh", joinDate: "2024-04-12", earnings: 150 },
  { name: "Rahul Mehra", joinDate: "2024-04-15", earnings: 100 },
];

export default function ReferralsPanel() {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(referralLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({ title: "Join GiftsHero!", url: referralLink });
    } else {
      alert("Sharing not supported on this device.");
    }
  };

  const totalEarnings = referrals.reduce((sum, r) => sum + r.earnings, 0);

  return (
    <div className="referral-dashboard-panel">
      <div className="referral-top-row">
        <div className="referral-link-box">
          <div className="referral-link-label"><LinkIcon size={18} /> Your Referral Link</div>
          <div className="referral-link-row">
            <input className="referral-link-input" value={referralLink} readOnly />
            <button className="referral-copy-btn" onClick={handleCopy}><Copy size={16} /> {copied ? "Copied!" : "Copy"}</button>
            <button className="referral-share-btn" onClick={handleShare}><Share2 size={16} /> Share</button>
          </div>
        </div>
        <div className="referral-qr-box">
          <div className="referral-qr-label">QR Code</div>
          <div className="qr-code-wrapper" style={{ position: 'relative', width: 110, height: 110, margin: '0 auto' }}>
            <QRCode value={referralLink} size={110} fgColor="#7c3aed" bgColor="#f8fbff" style={{ width: '100%', height: '100%' }} />
            <img
              src="/logo192.png"
              alt="Logo"
              style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                width: 36,
                height: 36,
                transform: 'translate(-50%, -50%)',
                borderRadius: '8px',
                background: '#fff',
                boxShadow: '0 1px 4px 0 rgba(124, 58, 237, 0.10)'
              }}
            />
          </div>
        </div>
        {/* <div className="referral-stats-box">
          <div className="referral-stats-title"><Users size={18} />     Referral Stats</div>
          <div className="referral-stats-row">
            <div className="referral-stat">
              <div className="referral-stat-label">Direct Referrals</div>
              <div className="referral-stat-value">{referrals.length}</div>
            </div>
            <div className="referral-stat">
              <div className="referral-stat-label">Total Earnings</div>
              <div className="referral-stat-value">₹{totalEarnings}</div>
            </div>
          </div>
        </div> */}
      </div>
      <div className="referral-table-section">
        <div className="referral-table-title"><Gift size={18} /> Your Direct Referrals</div>
        <table className="referral-table referral-table-cards">
          <thead>
            <tr>
              <th>Name</th>
              <th>Join Date</th>
              <th>Earnings</th>
            </tr>
          </thead>
          <tbody>
            {referrals.map((ref, i) => (
              <tr key={i} className="referral-table-row">
                <td>
                  <div className="referral-user-name">{ref.name}</div>
                </td>
                <td>
                  <span className="referral-badge referral-date-badge"><Calendar size={14} /> {ref.joinDate}</span>
                </td>
                <td>
                  <span className="referral-badge referral-earnings-badge"><DollarSign size={14} /> ₹{ref.earnings}</span>
                </td>
              </tr>
            ))}
            <tr className="referral-table-summary">
              <td colSpan={2} className="referral-table-summary-label">Total Earnings</td>
              <td className="referral-table-summary-value">₹{totalEarnings}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
} 