import React, { useState } from "react";
import { Gift, Award } from "react-feather";
import "./RewardsPanel.css";

const userTier = "Silver"; // Bronze, Silver, Gold
const progress = 65; // percent to next tier
const claimableRewards = [
  { id: 1, title: "₹100 Cashback", points: 100, status: "claimable" },
  { id: 2, title: "Free Shipping", points: 50, status: "claimable" },
];
const rewardHistory = [
  { date: "2024-05-01", source: "Referral Bonus", points: 50, status: "Claimed" },
  { date: "2024-04-28", source: "Level Up", points: 100, status: "Claimed" },
  { date: "2024-04-20", source: "Purchase Cashback", points: 30, status: "Claimed" },
  { date: "2024-04-15", source: "Referral Bonus", points: 50, status: "Claimed" },
];

export default function RewardsPanel() {
  const [claimed, setClaimed] = useState<number[]>([]);

  const handleClaim = (id: number) => {
    setClaimed((prev) => [...prev, id]);
  };

  return (
    <div className="rewards-dashboard-panel">
      <div className="rewards-tier-card rewards-card">
        <div className="rewards-tier-header">
          <Award size={22} />
          <span className={`rewards-tier-badge rewards-tier-${userTier.toLowerCase()}`}>{userTier}</span>
        </div>
        <div className="rewards-tier-progress-label">Progress to next tier</div>
        <div className="rewards-tier-progress-bar-bg">
          <div className={`rewards-tier-progress-bar rewards-tier-${userTier.toLowerCase()}`} style={{ width: `${progress}%` }} />
        </div>
        <div className="rewards-tier-progress-text">{progress}% to Gold</div>
      </div>
      <div className="rewards-claim-section rewards-card">
        <div className="rewards-claim-title"><Gift size={18} /> Claimable Rewards</div>
        <div className="rewards-claim-list">
          {claimableRewards.map((reward) => (
            <div className="rewards-claim-card" key={reward.id}>
              <div className="rewards-claim-info">
                <span className="rewards-claim-title-text">{reward.title}</span>
                <span className="rewards-claim-points-badge">{reward.points} pts</span>
              </div>
              <button
                className="rewards-claim-btn"
                disabled={claimed.includes(reward.id)}
                onClick={() => handleClaim(reward.id)}
              >
                {claimed.includes(reward.id) ? "Claimed" : "Claim Reward"}
              </button>
            </div>
          ))}
        </div>
      </div>
      <div className="rewards-history-section rewards-card">
        <div className="rewards-history-title"><Gift size={18} /> Reward History</div>
        <table className="rewards-history-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Source</th>
              <th>Points</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rewardHistory.map((reward, i) => (
              <tr key={i}>
                <td>{reward.date}</td>
                <td>{reward.source}</td>
                <td>{reward.points}</td>
                <td><span className="rewards-history-status-badge">{reward.status}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
} 