import React, { useState } from "react";
import "./UserProfilePanel.css";

export default function UserProfilePanel() {
  const [form, setForm] = useState({
    name: "John Doe",
    email: "johndoe@email.com",
    mobile: "+91-9876543210",
    address: "123 Main St, Mumbai",
    gender: "male",
  });
  const [copied, setCopied] = useState(false);
  const referralCode = "GH1234";
  const createdDate = "2023-10-15";

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 1200);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Add update logic here
    alert("Profile updated (demo)");
  };

  return (
    <div className="profile-settings-panel">
      <form className="profile-settings-form" onSubmit={handleSubmit}>
        <div className="profile-settings-left">
          <div className="profile-photo-large">
            <img src="https://randomuser.me/api/portraits/men/32.jpg" alt="User" className="profile-photo-img" />
          </div>
          <div className="profile-referral-box">
            <div className="profile-referral-label">Referral Code</div>
            <div className="profile-referral-row">
              <span className="profile-referral-code">{referralCode}</span>
              <button type="button" className="copy-btn" onClick={handleCopy}>{copied ? "Copied!" : "Copy"}</button>
            </div>
          </div>
          <div className="profile-created-date">Account Created: {createdDate}</div>
        </div>
        <div className="profile-settings-right">
        <div className="profile-field-group">
            <label>Name</label>
            <input name="name" value={form.name} onChange={handleChange} className="profile-input" />
          </div>
          <div className="profile-field-group">
            <label>Email</label>
            <input name="email" value={form.email} onChange={handleChange} className="profile-input" type="email" />
          </div>
          <div className="profile-field-group">
            <label>Mobile</label>
            <input name="mobile" value={form.mobile} onChange={handleChange} className="profile-input" />
          </div>
          <div className="profile-field-group">
            <label>Address</label>
            <textarea name="address" value={form.address} onChange={handleChange} className="profile-input" rows={2} />
          </div>
          <div className="profile-field-group">
            <label>Gender</label>
            <select name="gender" value={form.gender} onChange={handleChange} className="profile-input">
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>

          <button className="profile-update-btn" type="submit">Update Profile</button>
        </div>
      </form>
    </div>
  );
} 