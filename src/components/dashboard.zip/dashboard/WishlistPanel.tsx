import React, { useState } from "react";
import { X, ShoppingCart } from "react-feather";
import "./WishlistPanel.css";

const products = [
  { id: 1, title: "Wireless Earbuds", price: 1999, image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=facearea&w=400&q=80", category: "Electronics" },
  { id: 2, title: "Smart Watch", price: 2999, image: "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=facearea&w=400&q=80", category: "Electronics" },
  { id: 3, title: "Gift Card", price: 500, image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=facearea&w=400&q=80", category: "Gift" },
  { id: 4, title: "Bluetooth Speaker", price: 1499, image: "https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=facearea&w=400&q=80", category: "Electronics" },
  { id: 5, title: "Fitness Band", price: 999, image: "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=facearea&w=400&q=80", category: "Fitness" },
];

const categories = ["All", ...Array.from(new Set(products.map(p => p.category)))];
const priceRanges = [
  { label: "All", min: 0, max: Infinity },
  { label: "Under ₹1000", min: 0, max: 1000 },
  { label: "₹1000 - ₹2000", min: 1000, max: 2000 },
  { label: "Above ₹2000", min: 2000, max: Infinity },
];

export default function WishlistPanel() {
  const [category, setCategory] = useState("All");
  const [price, setPrice] = useState("All");
  const [items, setItems] = useState(products);

  const filtered = items.filter(p =>
    (category === "All" || p.category === category) &&
    (price === "All" || (p.price >= priceRanges.find(r => r.label === price)!.min && p.price <= priceRanges.find(r => r.label === price)!.max))
  );

  const handleRemove = (id: number) => setItems(items.filter(p => p.id !== id));
  const handleMoveToCart = (id: number) => {
    setItems(items.filter(p => p.id !== id));
    // Add to cart logic here
    alert("Moved to cart (demo)");
  };

  return (
    <div className="wishlist-dashboard-panel">
      <div className="wishlist-filters-row">
        <div className="wishlist-filter-group">
          <label>Category:</label>
          <select value={category} onChange={e => setCategory(e.target.value)} className="wishlist-filter-select">
            {categories.map(cat => <option key={cat} value={cat}>{cat}</option>)}
          </select>
        </div>
        <div className="wishlist-filter-group">
          <label>Price:</label>
          <select value={price} onChange={e => setPrice(e.target.value)} className="wishlist-filter-select">
            {priceRanges.map(r => <option key={r.label} value={r.label}>{r.label}</option>)}
          </select>
        </div>
      </div>
      <div className="wishlist-grid">
        {filtered.map(product => (
          <div className="wishlist-card" key={product.id}>
            <button className="wishlist-remove-btn" onClick={() => handleRemove(product.id)}><X size={18} /></button>
            <img src={product.image} alt={product.title} className="wishlist-card-img" />
            <div className="wishlist-card-title">{product.title}</div>
            <div className="wishlist-card-price">₹{product.price}</div>
            <button className="wishlist-move-btn" onClick={() => handleMoveToCart(product.id)}><ShoppingCart size={16} /> Move to Cart</button>
          </div>
        ))}
        {filtered.length === 0 && <div className="wishlist-empty">No products found.</div>}
      </div>
    </div>
  );
} 